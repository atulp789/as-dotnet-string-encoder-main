using System;
using System.Collections.Generic;

namespace Encoder
{
    public class EncoderProcessor
    {
        Dictionary<char, int> dictVowels = new Dictionary<char, int>();
        public EncoderProcessor()
        {
            dictVowels.Add('a', 1);
            dictVowels.Add('e', 2);
            dictVowels.Add('i', 3);
            dictVowels.Add('o', 4);
            dictVowels.Add('u', 5);
        }

        public string Encode(string message)
        {
            int startIndex = -1;
            int endIndex = 0;
            char[] messageArray = message.ToLower().ToCharArray();

            for (int i = 0; i < messageArray.Length; i++)
            {
                if (Char.IsNumber(messageArray[i]))
                {
                    if (startIndex == -1)
                        startIndex = i;
                    endIndex = i;

                    if (i != messageArray.Length - 1)
                        continue;
                }

                if (startIndex > -1)
                {
                    while (startIndex < endIndex)
                    {
                        var tempValue = messageArray[endIndex];
                        messageArray[endIndex] = messageArray[startIndex];
                        messageArray[startIndex] = tempValue;
                        startIndex++;
                        endIndex--;
                    }
                    startIndex = -1;
                    endIndex = 0;
                }
                
                if (dictVowels.ContainsKey(messageArray[i]))
                {
                    messageArray[i] = Char.Parse(dictVowels[messageArray[i]].ToString());
                }
                else if (messageArray[i] == 'y')
                {
                    messageArray[i] = ' ';
                }
                else if (messageArray[i] == ' ')
                {
                    messageArray[i] = 'y';
                }
                else if ((int)messageArray[i] >= (int)'a' && (int)messageArray[i] <= (int)'z')
                {
                    int preValue = (int)messageArray[i] - 1;
                    messageArray[i] = (char)preValue;
                }
            }

            return string.Join("", messageArray);
        }
    }
}